<?php
require_once __DIR__ . '/../../includes/bootstrap.php';

const EQUIPMENT_SELECT = '
    SELECT e.equipment_id, e.equipment_name, e.description, e.serial_number, e.status,
           e.category_id, c.category_name, e.created_at
    FROM equipment e
    LEFT JOIN categories c ON c.category_id = e.category_id
';

$allowedSort = ['equipment_name', 'status', 'created_at'];

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {

    case 'GET':
        requireLogin();
        if (isset($_GET['id'])) {
            $stmt = $db->prepare(EQUIPMENT_SELECT . ' WHERE e.equipment_id = :id');
            $stmt->execute(['id' => $_GET['id']]);
            $item = $stmt->fetch();
            if (!$item) {
                sendJson(404, ['success' => false, 'message' => 'Equipment not found.']);
            }
            sendJson(200, ['success' => true, 'data' => $item]);
        }

        $sql = EQUIPMENT_SELECT;
        $conditions = [];
        $params = [];

        if (!empty($_GET['search'])) {
            $conditions[] = '(e.equipment_name LIKE :search OR e.description LIKE :search OR e.serial_number LIKE :search)';
            $params['search'] = '%' . $_GET['search'] . '%';
        }
        if (!empty($_GET['category_id'])) {
            $conditions[] = 'e.category_id = :category_id';
            $params['category_id'] = $_GET['category_id'];
        }
        if (!empty($_GET['status'])) {
            $conditions[] = 'e.status = :status';
            $params['status'] = $_GET['status'];
        }
        if ($conditions) {
            $sql .= ' WHERE ' . implode(' AND ', $conditions);
        }

        $sortBy = in_array($_GET['sort_by'] ?? '', $allowedSort, true) ? $_GET['sort_by'] : 'equipment_name';
        $sortDir = (strtoupper($_GET['sort_dir'] ?? '') === 'DESC') ? 'DESC' : 'ASC';
        $sql .= " ORDER BY e.$sortBy $sortDir";

        $page   = max(1, (int)($_GET['page'] ?? 1));
        $limit  = min(50, max(1, (int)($_GET['limit'] ?? 20)));
        $offset = ($page - 1) * $limit;
        $sql .= ' LIMIT :limit OFFSET :offset';

        $stmt = $db->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue(":$key", $val);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        sendJson(200, ['success' => true, 'data' => $stmt->fetchAll(), 'page' => $page, 'limit' => $limit]);
        break;

    case 'POST':
        requireRole(['admin']);
        $body = getJsonBody();
        $name = cleanText($body['equipment_name'] ?? '');
        $description = cleanText($body['description'] ?? '');
        $serialNumber = cleanText($body['serial_number'] ?? '');
        $categoryId = $body['category_id'] ?? null;
        $status = $body['status'] ?? 'available';
        if ($name === '') {
            sendJson(400, ['success' => false, 'message' => 'equipment_name is required.']);
        }
        if (strlen($name) > 150 || strlen($description) > 500 || strlen($serialNumber) > 100) {
            sendJson(400, ['success' => false, 'message' => 'One or more equipment fields are too long.']);
        }
        if (!in_array($status, ['available', 'borrowed', 'maintenance'], true)) {
            sendJson(400, ['success' => false, 'message' => 'Invalid equipment status.']);
        }
        try {
            $stmt = $db->prepare(
                'INSERT INTO equipment (equipment_name, description, serial_number, category_id, status)
                 VALUES (:name, :description, :serial_number, :category_id, :status)'
            );
            $stmt->execute([
                'name'          => $name,
                'description'   => $description,
                'serial_number' => $serialNumber ?: null,
                'category_id'   => $categoryId ?: null,
                'status'        => $status,
            ]);
            sendJson(201, ['success' => true, 'message' => 'Equipment added.', 'data' => ['equipment_id' => (int)$db->lastInsertId()]]);
        } catch (PDOException $e) {
            sendJson(409, ['success' => false, 'message' => 'Could not add equipment. The serial number may already be in use.']);
        }
        break;

    case 'PUT':
        requireRole(['admin']);
        $body = getJsonBody();
        $id = $body['equipment_id'] ?? null;
        if (!$id) {
            sendJson(400, ['success' => false, 'message' => 'equipment_id is required.']);
        }
        $name = cleanText($body['equipment_name'] ?? '');
        $description = cleanText($body['description'] ?? '');
        $serialNumber = cleanText($body['serial_number'] ?? '');
        $categoryId = $body['category_id'] ?? null;
        $status = $body['status'] ?? 'available';
        if ($name === '') {
            sendJson(400, ['success' => false, 'message' => 'equipment_name is required.']);
        }
        if (strlen($name) > 150 || strlen($description) > 500 || strlen($serialNumber) > 100) {
            sendJson(400, ['success' => false, 'message' => 'One or more equipment fields are too long.']);
        }
        if (!in_array($status, ['available', 'borrowed', 'maintenance'], true)) {
            sendJson(400, ['success' => false, 'message' => 'Invalid equipment status.']);
        }
        $stmt = $db->prepare(
            'UPDATE equipment
             SET equipment_name = :name, description = :description, serial_number = :serial_number,
                 category_id = :category_id, status = :status
             WHERE equipment_id = :id'
        );
        $stmt->execute([
            'name'          => $name,
            'description'   => $description,
            'serial_number' => $serialNumber ?: null,
            'category_id'   => $categoryId ?: null,
            'status'        => $status,
            'id'            => $id,
        ]);
        sendJson(200, ['success' => true, 'message' => 'Equipment updated.']);
        break;

    case 'DELETE':
        requireRole(['admin']);
        $id = $_GET['id'] ?? null;
        if (!$id) {
            sendJson(400, ['success' => false, 'message' => 'id query param is required.']);
        }
        $stmt = $db->prepare('DELETE FROM equipment WHERE equipment_id = :id');
        $stmt->execute(['id' => $id]);
        if ($stmt->rowCount() === 0) {
            sendJson(404, ['success' => false, 'message' => 'Equipment not found.']);
        }
        sendJson(200, ['success' => true, 'message' => 'Equipment deleted.']);
        break;

    default:
        sendJson(405, ['success' => false, 'message' => 'Method not allowed.']);
}
